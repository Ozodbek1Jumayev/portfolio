# <a href="https://people.umass.edu/avsingh" target="_blank">My Alternate Portfolio Website</a>

[![Repository Status](https://img.shields.io/badge/Repository%20Status-Maintained-dark%20green.svg)](https://github.com/AVS1508/My-Alternate-Portfolio-Website/)
[![Website Status](https://img.shields.io/badge/Website%20Status-Online-green)](https://people.umass.edu/avsingh)
[![Author](https://img.shields.io/badge/Author-Aditya%20Vikram%20Singh-blue.svg)](https://www.linkedin.com/in/AVS1508/)
[![Latest Release](https://img.shields.io/badge/Latest%20Release-13%20June%202021-yellow.svg)](https://github.com/AVS1508/My-Alternate-Portfolio-Website/commit/master)

 <p align="justify">and Gulp.js.Ushbu veb-sayt mening veb-saytlarimni, rezyumeni, hikoyam va Particle.js bilan moslangan mavzudagi taniqli loyihalarimni namoyish qilish uchun onlayn portfel sifatida xizmat qiladi. U Jekyll, Sass yordamida yaratilgan.</p>

![My Alternate Portfolio Website](https://raw.githubusercontent.com/AVS1508/My-Alternate-Portfolio-Website/master/My-Alternate-Portfolio-Website.jpg)

Agar veb-sayt haqida fikr-mulohazalaringiz yoki fikringiz bo'lsa, iltimos, menga avsingh@umass.edu manziliga murojaat qiling. :yulduzcha qoldiring: &nbsp;agar sizga yoqsa!
